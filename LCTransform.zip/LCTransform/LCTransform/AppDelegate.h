//
//  AppDelegate.h
//  LCTransform
//
//  Created by lc-macbook pro on 2017/9/27.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

