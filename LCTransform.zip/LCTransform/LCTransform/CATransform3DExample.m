//
//  CATransform3DExample.m
//  LCTransform
//
//  Created by lc-macbook pro on 2017/9/27.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "CATransform3DExample.h"

@interface CATransform3DExample ()

@end

@implementation CATransform3DExample

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (UIImageView *)myImageView {
    if (_myImageView == nil) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.image = [UIImage imageNamed:@"1"];
        imageView.backgroundColor = [UIColor orangeColor];
        
        imageView.frame = CGRectMake((kScreenWidth-200)/2.0, (kScreenHeight-200)/2.0, 200, 200);
        [self.view addSubview:imageView];
        
        _myImageView = imageView;
    }
    return _myImageView;
}


- (UIImageView *)containerView {
    if (_myImageView == nil) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.backgroundColor = [UIColor lightGrayColor];
        imageView.frame = self.view.bounds;
        
        [self.view addSubview:imageView];
        
        _containerView = imageView;
        
        [_containerView addSubview:self.layerView1];
        [_containerView addSubview:self.layerView2];
    }
    return _containerView;
}


- (UIImageView *)layerView1 {
    if (_layerView1 == nil) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.image = [UIImage imageNamed:@"1"];
        imageView.backgroundColor = [UIColor orangeColor];
        
        imageView.frame = CGRectMake(kScreenWidth/2.0-200, (kScreenHeight-200)/2.0, 200, 200);
        [self.view addSubview:imageView];
        
        _layerView1 = imageView;
    }
    return _layerView1;
}

- (UIImageView *)layerView2 {
    if (_layerView2 == nil) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.image = [UIImage imageNamed:@"1"];
        imageView.backgroundColor = [UIColor blueColor];
        
        imageView.frame = CGRectMake(kScreenWidth/2.0, (kScreenHeight-200)/2.0, 200, 200);
        [self.view addSubview:imageView];
        
        _layerView2 = imageView;
    }
    return _layerView2;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
