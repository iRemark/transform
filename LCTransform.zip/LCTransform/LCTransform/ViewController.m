//
//  ViewController.m
//  LCTransform
//
//  Created by lc-macbook pro on 2017/9/27.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "ViewController.h"
#import "CATransform3DExample.h"


static NSString *cellID = @"ViewController";

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self initUI];
    
    self.dataArr = [NSMutableArray array];
    [self.dataArr addObject:@{@"title":@"绕Y旋转",@"key":@"rotationY"}];
    [self.dataArr addObject:@{@"title":@"绕Y旋转_透视投影",@"key":@"rotationY_and_m34"}];
    [self.dataArr addObject:@{@"title":@"共享m34",@"key":@"sublayerTransform"}];
    [self.dataArr addObject:@{@"title":@"背面",@"key":@"background"}];
    [self.dataArr addObject:@{@"title":@"扁平化图层",@"key":@"outer_inner"}];
}

- (void)initUI {
    self.tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    self.tableView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-64);
    [self.view addSubview:self.tableView];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}

#pragma mark - <UITableViewDelegate,UITableViewDataSource>
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSDictionary *dic = self.dataArr[indexPath.row];
    cell.textLabel.text = dic[@"title"];
    cell.detailTextLabel.text = dic[@"key"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    NSDictionary *dic = self.dataArr[indexPath.row];
    
    CATransform3DExample *vc = [[CATransform3DExample alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
    vc.title = dic[@"title"];
    vc.navigationItem.prompt = dic[@"key"];
    
    [self transformWithKey:dic[@"key"] exampleVC:vc];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)transformWithKey:(NSString *)key exampleVC:(CATransform3DExample *)exampleVC {
    if ([key isEqualToString:@"rotationY"]) {//绕Y旋转
        CATransform3D transform = CATransform3DMakeRotation(M_PI_4, 0, 1, 0);
        exampleVC.myImageView.layer.transform = transform;
    }
    else if ([key isEqualToString:@"rotationY_and_m34"])  {//绕Y旋转_透视投影
        //create a new transform
        CATransform3D transform = CATransform3DIdentity;
        //apply perspective
        transform.m34 = - 1.0 / 500.0;
        //rotate by 45 degrees along the Y axis
        transform = CATransform3DRotate(transform, M_PI_4, 0, 1, 0);
        //apply to layer
         exampleVC.myImageView.layer.transform = transform;
    }
    else if ([key isEqualToString:@"sublayerTransform"]) {//共享m34
        /** CALayer有一个属性叫做sublayerTransform。它也是CATransform3D类型，但和对一个图层的变换不同，它影响到所有的子图层。这意味着你可以一次性对包含这些图层的容器做变换，于是所有的子图层都自动继承了这个变换方法。 **/
        CATransform3D perspective = CATransform3DIdentity;
        perspective.m34 = - 1.0 / 500.0;
        exampleVC.containerView.layer.sublayerTransform = perspective;
        
        //rotate layerView1 by 45 degrees along the Y axis
        CATransform3D transform1 = CATransform3DMakeRotation(M_PI_4, 0, 1, 0);
        exampleVC.layerView1.layer.transform = transform1;
        
        //rotate layerView2 by 45 degrees along the Y axis
        CATransform3D transform2 = CATransform3DMakeRotation(-M_PI_4, 0, 1, 0);
        exampleVC.layerView2.layer.transform = transform2;
        
    }else if ([key isEqualToString:@"background"]) {//背面
       
        CATransform3D transform = CATransform3DMakeRotation(M_PI, 0, 1, 0);
        exampleVC.myImageView.layer.transform = transform;
        
        //背面不绘制 默认yes
        exampleVC.myImageView.layer.doubleSided = NO;//不绘制就看不到了
        
    }else if ([key isEqualToString:@"outer_inner"]) {// 扁平化图层
        CATransform3D outer = CATransform3DMakeRotation(0, 0, 0, 1);
        exampleVC.layerView1.layer.transform = outer;
        
        CATransform3D inner = CATransform3DMakeRotation(-0, 0, 0, 1);
        exampleVC.layerView2.layer.transform = inner;

    }
}

@end




























